#pragma once

#include <Arduino.h>
#ifdef ARDUINO_ARCH_STM32
#include <Wire.h>
#endif // ARDUINO_ARCH_STM32

#define WIO_DEBUG
