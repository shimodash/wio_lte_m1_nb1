#pragma once

#include "WioCellularConfig.h"

#include <map>

class WioCellularHttpHeader : public std::map<String, String>
{
};
